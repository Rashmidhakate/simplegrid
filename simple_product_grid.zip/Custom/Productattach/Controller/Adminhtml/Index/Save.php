<?php
namespace Custom\Productattach\Controller\Adminhtml\Index;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Backend\App\Action;
use Magento\TestFramework\ErrorLog\Logger;

class Save extends \Magento\Backend\App\Action
{
    protected $cacheTypeList;
    protected $jsHelper;

    const ADMIN_RESOURCE = 'Custom_Productattach::save';
    protected $adapterFactory;
    protected $uploader;
    protected $filesystem;


    protected $_filesystem;
    protected $_storeManager;
    protected $_directory;
    protected $_imageFactory;

    public function __construct(
        Action\Context $context,
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
        \Magento\Backend\Helper\Js $jsHelper,
        \Magento\Framework\Image\AdapterFactory $adapterFactory,
        \Magento\MediaStorage\Model\File\UploaderFactory $uploader,        

        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Image\AdapterFactory $imageFactory
    )
    {        
        $this->_storeManager = $storeManager;
        $this->_directory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_imageFactory = $imageFactory;

        $this->adapterFactory = $adapterFactory;
        $this->uploader = $uploader;
        $this->filesystem = $filesystem;
        $this->cacheTypeList = $cacheTypeList;
        parent::__construct($context);
        $this->jsHelper = $jsHelper;
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed(self::ADMIN_RESOURCE);
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        $new_prd_string = '';
        if(!empty($data["products"]) && strpos($data["products"], '&')){
            $prd_array = explode('&',$data["products"]);    
            $new_prd_string = implode(',', $prd_array);
        } else {
            $new_prd_string = $data['products'];
        }
    
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) {
            
            $model = $this->_objectManager->create('Custom\Productattach\Model\Productattach');

            $id = $this->getRequest()->getParam('productattach_id');
            if ($id) {
                $model->load($id);
            }
            $model->setName($data["name"]);
            $model->setDescription($data["description"]);
            $model->setUrl($data["url"]);
            $model->setCustomerGroup(implode(',', $data["customer_group"]));
            $model->setStore(implode(',', $data["store"]));
            $model->setActive($data["active"]);
            $model->setProducts($new_prd_string);

            try {
                $model->save();

                $this->cacheTypeList->invalidate('full_page');
                $this->messageManager->addSuccess(__('You saved this Attachment.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['productattach_id' => $model->getId(), '_current' => true]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the Attachment.'));
            }

            return $resultRedirect->setPath('*/*/edit', ['productattach_id' => $this->getRequest()->getParam('productattach_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    // public function imageResize($image, $width = null, $height = null,$absPath,$resizepath)
    // {

    //     $absPath = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath($absPath).$image;;
    //     //echo $absPath;exit;
    //     if(!file_exists($absPath)){
    //         return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'cp/events/images/resized/noimage.jpg';
    //     }
    //     $imageResized = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath($resizepath).$image;
    //     $imageResize = $this->_imageFactory->create();         
    //     $imageResize->open($absPath);
    //     $imageResize->constrainOnly(TRUE);         
    //     $imageResize->keepTransparency(TRUE);         
    //     $imageResize->keepFrame(FALSE);         
    //     $imageResize->keepAspectRatio(TRUE);         
    //     $imageResize->resize($width,$height);  
    //     $destination = $imageResized ;    
    //     $imageResize->save($destination);         
    //     $resizedURL= $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).$resizepath.$image;
    //     return $resizedURL;  
    // }
}
