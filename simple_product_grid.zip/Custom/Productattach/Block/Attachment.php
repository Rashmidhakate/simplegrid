<?php

namespace Custom\Productattach\Block;

class Attachment extends \Magento\Framework\View\Element\Template
{
	protected $_registry;
	public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Custom\Productattach\Model\ProductattachFactory $ProductattachFactory,
		\Custom\Productattach\Model\ResourceModel\Productattach\CollectionFactory $productattachCollectionFactory,
		\Magento\Framework\Registry $registry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		array $data = []
	){
		$this->_scopeConfig = $scopeConfig;
		$this->_registry = $registry;
		$this->ProductattachFactory = $ProductattachFactory;
		$this->storeManager = $storeManager;
		$this->productattachCollectionFactory = $productattachCollectionFactory;
        parent::__construct(
            $context,
            $data
        );
	}
	public function getConfig($config){
		return $this->_scopeConfig->getValue(
				$config, 
				\Magento\Store\Model\ScopeInterface::SCOPE_STORE
			);
	}
	public function isEnable(){
		$tabName = __($this->getConfig('productattach/general/enable'));
		return $tabName;
	}
	public function getTabName(){
		$tabName = __($this->getConfig('productattach/general/tabname'));
		return $tabName;
	}
	public function getCurrentProduct()
    {       
        $currentProductId = $this->_registry->registry('current_product');
        return $currentProductId->getId();
    }

    public function getAttachment(){
    	$collection = $this->productattachCollectionFactory->create();
		
		$collection->addFieldToFilter(
            'store',
            [
                ['eq' => 0],
                ['finset' => $this->getStoreId()]
            ]
        );

        $collection->addFieldToFilter(
            'products',array('finset' => $this->getCurrentProduct())
        );

    	return $collection;
    }

    public function getStoreId(){
    	return $this->_storeManager->getStore()->getId();
    }
}
