<?php
namespace Custom\Productattach\Model\ResourceModel;

use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Productattach extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('custom_productattach','productattach_id');
    }
}

