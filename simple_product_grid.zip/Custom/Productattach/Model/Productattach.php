<?php
namespace Custom\Productattach\Model;
class Productattach extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
        $this->_init('Custom\Productattach\Model\ResourceModel\Productattach');
    }
}

